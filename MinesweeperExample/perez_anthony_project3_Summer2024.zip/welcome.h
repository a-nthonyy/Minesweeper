#include <SFML/Graphics.hpp>
#include <string>
using namespace std;

void welcomewindow(int rows, int columns, bool& game, string &playername);
void setText(sf::Text &text, float x, float y);